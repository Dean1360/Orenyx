/**
 * Site-wide constants.
 * Nav and footer structure mirror the client Figma exactly.
 */

export const site = {
  name: 'Motus AI Engine',
  company: 'Motus Labs LLC',
  registeredIn: 'Wyoming',
  url: process.env.NEXT_PUBLIC_SITE_URL ?? 'https://motusaiengine.com',
  supportEmail: 'support@motuslabs.co',
  footerBlurb:
    'Motus AI Engine — unified decision plus orchestration layer for dispatch, bots, and payments.',
} as const;

export const primaryNav = [
  { label: 'Home', href: '/' },
  { label: 'About', href: '/about' },
  { label: 'Features', href: '/features' },
  { label: 'Pricing', href: '/pricing' },
  { label: 'Use Cases', href: '/use-cases' },
  { label: 'Developers', href: '/developers' },
  { label: 'Integrations', href: '/integrations' },
  { label: 'Security & Trust', href: '/security' },
] as const;

/** Thin bar above the header. */
export const utilityNav = [
  { label: 'Log in', href: '/login' },
  { label: 'Status', href: '/status' },
] as const;

export const footerNav = [
  {
    heading: 'Product',
    links: [
      { label: 'Features', href: '/features' },
      { label: 'Pricing', href: '/pricing' },
      { label: 'Use Cases', href: '/use-cases' },
      { label: 'Integrations', href: '/integrations' },
      { label: 'Security', href: '/security' },
    ],
  },
  {
    heading: 'Developers',
    links: [
      { label: 'API Docs', href: '/developers' },
      { label: 'Authentication', href: '/developers/authentication' },
      { label: 'Changelog', href: '/developers/changelog' },
      { label: 'Status', href: '/status' },
    ],
  },
  {
    heading: 'Company',
    links: [
      { label: 'About', href: '/about' },
      { label: 'Contact', href: '/contact' },
      { label: 'Careers', href: '/careers' },
      { label: 'FAQ', href: '/faq' },
    ],
  },
  {
    heading: 'Legal',
    links: [
      { label: 'Terms of Service', href: '/legal/terms' },
      { label: 'Privacy Policy', href: '/legal/privacy' },
      { label: 'Refund & Cancellation Policy', href: '/legal/refund' },
      { label: 'Data Processing Agreement', href: '/legal/dpa' },
    ],
  },
] as const;

/** Products shown in the hero diagram and the marquee strip. */
export const ecosystem = [
  { label: 'Motus Voice Dispatch', href: '#' },
  { label: 'Zyntriq Dispatch', href: 'https://zyntriqdispatch.com' },
  { label: 'Social Mention Bot', href: '#' },
  { label: 'Motus Payment', href: '#' },
] as const;
