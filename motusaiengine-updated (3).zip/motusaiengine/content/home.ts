/** Home page copy — verbatim from the client Figma. */

export const hero = {
  titleBefore: 'The ',
  titleAccent: 'AI engine',
  titleAfter: ' behind intelligent dispatch, payments & automation.',
  lead: 'Power Motus Voice Dispatch, Zyntriq Dispatch, Social Mention Bot, Motus Payment, and your own systems with one unified AI infrastructure.',
  primary: { label: 'Request Access', href: '/contact' },
  secondary: { label: 'View Pricing', href: '/pricing' },
};

/*
  ⚠ The Figma labels this block "Solution" but every line in it is a problem
  statement. Either the eyebrow should read "Problem" or the list is wrong.
  Kept verbatim; flagged for the client.
*/
export const problems = {
  eyebrow: 'Solution',
  title: ['One engine.', 'Every decision.'],
  items: [
    'Fragmented automation across disconnected tools',
    'Manual routing that doesn’t scale',
    'Slow, one-off integrations for every new system',
    'No central intelligence layer connecting decisions across products',
  ],
};

/*
  ⚠ This heading is identical to the block above it in the Figma — the same
  sentence runs twice in consecutive sections. Flagged for the client.
*/
export const solution = {
  eyebrow: 'Solution',
  title: 'One engine. Every decision.',
  lead: 'Motus AI Engine becomes the single decision layer for dispatch, payments, bots, and enterprise workflows — so every product in your stack shares the same intelligence instead of reinventing it.',
  capabilities: [
    'Intelligent dispatch routing',
    'Bot orchestration',
    'Payment decisioning',
    'API-first architecture',
    'Context + state management',
  ],
};

export const ecosystemBlock = {
  eyebrow: 'Ecosystem',
  // Figma reads "Availableto everyone else." — missing space corrected.
  title: ['Built inside the Motus ecosystem.', 'Available to everyone else.'],
  lead: 'The same engine powering the Motus ecosystem is available as a standalone platform.',
};

export const businessValue = {
  eyebrow: 'Solution',
  title: 'Business Value',
  items: [
    'Reduce manual operations',
    'Increase throughput',
    'Standardize logic across products',
    'Monetize automation as a first-class capability',
  ],
};

export const testimonials = {
  eyebrow: 'Testimonials',
  title: ['Trusted by teams building on', 'Motus infrastructure.'],
};

export const closingCta = {
  title: 'Ready to put one engine behind everything you build?',
  primary: { label: 'Talk to Sales', href: '/contact' },
  secondary: { label: 'Request Access', href: '/contact' },
};
