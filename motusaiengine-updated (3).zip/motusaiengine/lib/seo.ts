import type { Metadata } from 'next';
import { site } from '@/content/site';

type PageMetaInput = {
  title: string;
  description: string;
  path: string;
  noIndex?: boolean;
};

/** One place to build per-page metadata so titles and OG tags never drift. */
export function pageMeta({
  title,
  description,
  path,
  noIndex = false,
}: PageMetaInput): Metadata {
  const url = `${site.url}${path}`;
  const fullTitle = path === '/' ? `${site.name}` : `${title} — ${site.name}`;

  return {
    title: fullTitle,
    description,
    alternates: { canonical: url },
    robots: noIndex ? { index: false, follow: false } : undefined,
    openGraph: {
      title: fullTitle,
      description,
      url,
      siteName: site.name,
      type: 'website',
      // PLACEHOLDER — client has not supplied an Open Graph share image.
      images: [{ url: '/og-default.png', width: 1200, height: 630 }],
    },
    twitter: {
      card: 'summary_large_image',
      title: fullTitle,
      description,
    },
  };
}
