import { ButtonLink } from '@/components/ui/button';
import { CodeRain } from '@/components/code-rain';
import { EcosystemMarquee } from '@/components/marquee';
import { EngineDiagram } from '@/components/engine-diagram';
import { Logo } from '@/components/logo';
import { Placeholder } from '@/components/ui/placeholder';
import { ProblemList } from '@/components/problem-list';
import { Reveal } from '@/components/reveal';
import { Section, SectionHead, Shell } from '@/components/ui/section';
import { pageMeta } from '@/lib/seo';
import {
  businessValue,
  closingCta,
  ecosystemBlock,
  hero,
  problems,
  solution,
  testimonials,
} from '@/content/home';

export const metadata = pageMeta({
  title: 'Home',
  description: hero.lead,
  path: '/',
});

export default function HomePage() {
  return (
    <>
      {/* ── Hero ─────────────────────────────────────────── */}
      <div className="hero-band relative overflow-hidden">
        <Shell className="relative z-10 py-16 text-center md:py-20">
          <h1 className="homepage-title mx-auto max-w-[906px] text-4xl font-bold leading-[1.12] md:text-[3.25rem]">
            {hero.titleBefore}
            <span className="text-violet-soft">{hero.titleAccent}</span>
            {hero.titleAfter}
          </h1>

          <p className="mx-auto mt-6 max-w-[600px] text-base leading-relaxed text-white/85">
            {hero.lead}
          </p>

          <div className="mt-8 flex flex-wrap justify-center gap-3">
            <ButtonLink href={hero.primary.href}>{hero.primary.label}</ButtonLink>
            <ButtonLink href={hero.secondary.href} variant="outline">
              {hero.secondary.label}
            </ButtonLink>
          </div>

          <div className="mx-auto mt-12 max-w-[820px]">
            <EngineDiagram />
          </div>
        </Shell>
      </div>

      <EcosystemMarquee />

      {/* ── Problem split ────────────────────────────────── */}
      <div className="grid lg:grid-cols-2">
        <div className="bg-violet px-6 py-16 md:px-14 md:py-24">
          <div className="ml-auto max-w-[560px]">
            <p className="text-sm text-white/70">{problems.eyebrow}</p>
            <h2 className="mt-2 text-3xl font-bold leading-tight text-white md:text-[2.5rem]">
              {problems.title[0]}
              <br />
              {problems.title[1]}
            </h2>

            <ProblemList items={problems.items} />
          </div>
        </div>

        <div className="relative min-h-[280px] lg:min-h-0">
          <CodeRain className="absolute inset-0" />
        </div>
      </div>

      {/* ── Solution ─────────────────────────────────────── */}
      <Section pattern="dots">
        <Reveal>
          <SectionHead eyebrow={solution.eyebrow} title={solution.title} lead={solution.lead} />
        </Reveal>

        <Reveal>
          <div className="mt-12 grid border-l border-t border-line-violet sm:grid-cols-2 lg:grid-cols-3">
            {solution.capabilities.map((cap) => (
              <div
                key={cap}
                className="border-b border-r border-line-violet p-8 transition-colors hover:bg-bg-2"
              >
                <div className="mb-6 grid h-11 w-11 place-items-center rounded-[8px] border border-line-violet text-violet-bright">
                  <svg width="18" height="18" viewBox="0 0 18 18" fill="none" aria-hidden="true">
                    <rect
                      x="5"
                      y="5"
                      width="8"
                      height="8"
                      rx="1.5"
                      stroke="currentColor"
                      strokeWidth="1.4"
                    />
                    <path
                      d="M9 1v4M9 13v4M1 9h4M13 9h4"
                      stroke="currentColor"
                      strokeWidth="1.4"
                      strokeLinecap="round"
                    />
                  </svg>
                </div>
                <h3 className="text-xl font-bold leading-tight text-violet-bright">{cap}</h3>
              </div>
            ))}

            <div className="flex items-center justify-center border-b border-r border-line-violet p-8">
              <ButtonLink href="/features" variant="outline" arrow={false}>
                View All ↗
              </ButtonLink>
            </div>
          </div>
        </Reveal>
      </Section>

      {/* ── Ecosystem ────────────────────────────────────── */}
      <Section pattern="rings">
        <Reveal>
          <SectionHead
            align="center"
            silver
            eyebrow={ecosystemBlock.eyebrow}
            title={
              <>
                {ecosystemBlock.title[0]}
                <br />
                {ecosystemBlock.title[1]}
              </>
            }
            lead={ecosystemBlock.lead}
          />
        </Reveal>

        <Reveal>
          <div className="mt-14 flex flex-wrap items-center justify-center gap-x-20 gap-y-10">
            {[
              'Motus Voice Dispatch',
              'Zyntriq Dispatch',
              'Social Mention Bot',
              'Motus Payment',
            ].map((label) => (
              <div key={label} className="flex flex-col items-center gap-2 opacity-80">
                <Logo variant="footer" />
                <span className="sr-only">{label}</span>
              </div>
            ))}
          </div>
          <p className="mt-8 text-center">
            <Placeholder>individual product logo SVGs</Placeholder>
          </p>
        </Reveal>
      </Section>

      {/* ── Business value ───────────────────────────────── */}
      <Section tone="violet">
        <Reveal>
          <div className="text-center">
            <p className="text-sm text-white/70">{businessValue.eyebrow}</p>
            <h2 className="mt-2 text-3xl font-bold text-white md:text-[2.5rem]">
              {businessValue.title}
            </h2>
          </div>
        </Reveal>

        <div className="mt-12 grid gap-4 sm:grid-cols-2 lg:grid-cols-4">
          {businessValue.items.map((item, i) => (
            <Reveal key={item} delay={i * 70}>
              {/* Second card is inverted in the Figma. */}
              <div
                className={`flex h-full min-h-[220px] flex-col justify-end rounded-[10px] p-6 ${
                  i === 1 ? 'bg-bg text-white' : 'bg-lavender text-bg'
                }`}
              >
                <div className={`mb-auto ${i === 1 ? 'text-violet-bright' : 'text-bg'}`}>
                  <svg width="34" height="34" viewBox="0 0 34 34" fill="none" aria-hidden="true">
                    <path
                      d={i === 1 ? 'M9 24V10M17 24V6M25 24V13' : 'M9 10v14M17 10v14M25 10v14'}
                      stroke="currentColor"
                      strokeWidth="2"
                      strokeLinecap="round"
                    />
                  </svg>
                </div>
                <h3 className="text-xl font-bold leading-tight">{item}</h3>
              </div>
            </Reveal>
          ))}
        </div>
      </Section>

      {/* ── Testimonials ─────────────────────────────────── */}
      <Section pattern="glow">
        <Reveal>
          <p className="text-sm text-violet-soft">{testimonials.eyebrow}</p>
          <h2 className="heading-silver mt-2 max-w-[720px] text-3xl font-bold leading-tight md:text-[2.5rem]">
            {testimonials.title[0]}
            <br />
            {testimonials.title[1]}
          </h2>
        </Reveal>

        <div className="mt-12 grid gap-5 md:grid-cols-3">
          {[0, 1, 2].map((i) => (
            <Reveal key={i} delay={i * 70}>
              <div className="h-full rounded-[10px] bg-lavender p-6 text-bg">
                <p className="text-sm leading-relaxed">
                  <Placeholder>
                    testimonial {i + 1} quote — real customer, or approval to drop this section
                  </Placeholder>
                </p>
                <p className="mt-6 text-sm font-bold">
                  <Placeholder>name and role</Placeholder>
                </p>
              </div>
            </Reveal>
          ))}
        </div>
      </Section>

      {/* ── Closing CTA ──────────────────────────────────── */}
      <Section>
        <Reveal>
          <div className="rounded-panel bg-violet px-8 py-16 text-center md:px-16">
            <h2 className="mx-auto max-w-[620px] text-3xl font-bold leading-tight text-white md:text-[2.5rem]">
              {closingCta.title}
            </h2>
            <div className="mt-9 flex flex-wrap justify-center gap-3">
              <ButtonLink href={closingCta.primary.href} variant="dark">
                {closingCta.primary.label}
              </ButtonLink>
              <ButtonLink href={closingCta.secondary.href} variant="light">
                {closingCta.secondary.label}
              </ButtonLink>
            </div>
          </div>
        </Reveal>
      </Section>
    </>
  );
}
