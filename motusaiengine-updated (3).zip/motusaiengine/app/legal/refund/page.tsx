import { PageHero } from '@/components/page-hero';
import { Placeholder } from '@/components/ui/placeholder';
import { Section } from '@/components/ui/section';
import { pageMeta } from '@/lib/seo';

export const metadata = pageMeta({
  title: 'Refund & Cancellation Policy',
  description: 'Refund &amp; Cancellation Policy for Motus AI Engine, a product of Motus Labs LLC.',
  path: '/legal/refund',
});

/*
  Legal copy must be pasted verbatim from the client's counsel-approved
  document. Do not paraphrase, renumber clauses, or summarise.
*/

export default function Page() {
  return (
    <>
      <PageHero crumb="Refund &amp; Cancellation Policy" title="Refund &amp; Cancellation Policy" />
      <Section>
        <article className="max-w-[820px]">
          <p className="text-sm text-fg-muted">
            Last updated <Placeholder>effective date</Placeholder>
          </p>
          <div className="mt-8 space-y-4 leading-relaxed text-fg-soft">
            <p>
              <Placeholder>full refund & cancellation policy text — awaiting counsel-approved copy</Placeholder>
            </p>
          </div>
        </article>
      </Section>
    </>
  );
}
