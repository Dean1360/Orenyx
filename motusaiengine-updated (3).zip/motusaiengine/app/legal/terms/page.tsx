import { PageHero } from '@/components/page-hero';
import { Placeholder } from '@/components/ui/placeholder';
import { Section } from '@/components/ui/section';
import { pageMeta } from '@/lib/seo';

export const metadata = pageMeta({
  title: 'Terms of Service',
  description: 'Terms of Service for Motus AI Engine, a product of Motus Labs LLC.',
  path: '/legal/terms',
});

/*
  Legal copy must be pasted verbatim from the client's counsel-approved
  document. Do not paraphrase, renumber clauses, or summarise.
*/

export default function Page() {
  return (
    <>
      <PageHero crumb="Terms of Service" title="Terms of Service" />
      <Section>
        <article className="max-w-[820px]">
          <p className="text-sm text-fg-muted">
            Last updated <Placeholder>effective date</Placeholder>
          </p>
          <div className="mt-8 space-y-4 leading-relaxed text-fg-soft">
            <p>
              <Placeholder>full terms of service text — awaiting counsel-approved copy</Placeholder>
            </p>
          </div>
        </article>
      </Section>
    </>
  );
}
