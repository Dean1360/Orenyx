import { PageHero } from '@/components/page-hero';
import { Placeholder } from '@/components/ui/placeholder';
import { Reveal } from '@/components/reveal';
import { Section } from '@/components/ui/section';
import { pageMeta } from '@/lib/seo';

export const metadata = pageMeta({
  title: 'About',
  description:
    'Motus Labs LLC is a Wyoming company focused on AI-driven dispatch, automation, and payment infrastructure.',
  path: '/about',
});

/* Verbatim from the Figma. Company Story and the stat labels are lorem in the
   comp, so they stay as placeholders until the client supplies real copy. */
const facts = [
  'Wyoming-based',
  'Focus: AI-driven dispatch, automation, and payment infrastructure',
  'Founded by : Cliff, Founder/CEO',
];

const stats = ['20+', '90%', '80%', '100+'];

function FactIcon() {
  return (
    <svg
      width="26"
      height="26"
      viewBox="0 0 26 26"
      fill="none"
      aria-hidden="true"
      className="mt-0.5 shrink-0 text-white"
    >
      <circle cx="13" cy="13" r="11.5" stroke="currentColor" strokeWidth="1.4" />
      <path
        d="M8 13h9M14 10l3 3-3 3"
        stroke="currentColor"
        strokeWidth="1.4"
        strokeLinecap="round"
        strokeLinejoin="round"
      />
    </svg>
  );
}

export default function AboutPage() {
  return (
    <>
      <PageHero crumb="About" title="About Us" />

      {/* ── Company facts panel ──────────────────────────── */}
      <Section>
        <Reveal>
          <div className="relative overflow-hidden rounded-[14px] bg-violet px-7 py-12 md:px-12">
            <h2 className="max-w-[380px] text-3xl font-bold leading-tight text-white md:text-[2.5rem]">
              About Motus Labs LLC
            </h2>

            <ul className="mt-10 divide-y divide-white/25 border-t border-white/25">
              {facts.map((fact) => (
                <li key={fact} className="flex gap-5 py-6">
                  <FactIcon />
                  <span className="text-xl font-bold leading-snug text-white">{fact}</span>
                </li>
              ))}
            </ul>
          </div>
        </Reveal>
      </Section>

      {/* ── Company story ────────────────────────────────── */}
      <Section pattern="dots">
        <Reveal>
          <p className="text-lg text-violet-soft">About Us</p>
          <h2 className="heading-silver mt-2 text-3xl font-bold md:text-[2.5rem]">Company Story</h2>
        </Reveal>

        <div className="mt-10 grid items-start gap-12 lg:grid-cols-2">
          <Reveal>
            <div className="space-y-5 text-sm leading-relaxed text-fg-soft">
              <p>
                <Placeholder>company story paragraph 1 — lorem in the Figma</Placeholder>
              </p>
              <p>
                <Placeholder>company story paragraph 2 — lorem in the Figma</Placeholder>
              </p>
            </div>
          </Reveal>

          <Reveal delay={80}>
            <div className="grid aspect-[16/9] place-items-center rounded-[10px] border border-line-violet bg-bg-2">
              <p className="px-6 text-center">
                <Placeholder>company story image asset</Placeholder>
              </p>
            </div>
          </Reveal>
        </div>

        {/* ── Stats ──────────────────────────────────────── */}
        <Reveal>
          <h3 className="mt-20 max-w-[520px] text-2xl font-bold leading-snug text-fg-silver">
            <Placeholder>stats section heading — lorem in the Figma</Placeholder>
          </h3>

          <dl className="mt-10 grid grid-cols-2 gap-10 lg:grid-cols-4">
            {stats.map((value) => (
              <div key={value}>
                <dd className="text-5xl font-bold text-fg-silver md:text-6xl">{value}</dd>
                <dt className="mt-2 text-lg text-fg-soft">
                  <Placeholder>stat label</Placeholder>
                </dt>
              </div>
            ))}
          </dl>
        </Reveal>
      </Section>
    </>
  );
}
