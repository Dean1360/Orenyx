import { PageHero } from '@/components/page-hero';
import { Placeholder } from '@/components/ui/placeholder';
import { Reveal } from '@/components/reveal';
import { Section } from '@/components/ui/section';
import { pageMeta } from '@/lib/seo';
import { comparisonRows, coreModules, featuresHero, technicalHighlights } from '@/content/features';

export const metadata = pageMeta({
  title: 'Features',
  description: featuresHero.lead,
  path: '/features',
});

function ModuleIcon() {
  return (
    <div className="mb-6 grid h-11 w-11 place-items-center rounded-[8px] border border-line-violet text-violet-bright">
      <svg width="18" height="18" viewBox="0 0 18 18" fill="none" aria-hidden="true">
        <rect x="5" y="5" width="8" height="8" rx="1.5" stroke="currentColor" strokeWidth="1.4" />
        <path
          d="M9 1v4M9 13v4M1 9h4M13 9h4"
          stroke="currentColor"
          strokeWidth="1.4"
          strokeLinecap="round"
        />
      </svg>
    </div>
  );
}

export default function FeaturesPage() {
  const [first, second, ...rest] = coreModules;

  return (
    <>
      <PageHero
        crumb="Features"
        lead={featuresHero.lead}
        title={
          <>
            {featuresHero.titleBefore}
            <br className="hidden md:block" />
            <span className="text-violet-soft">{featuresHero.titleAccent}</span>
            {featuresHero.titleAfter}
          </>
        }
      />

      {/* ── Core modules ─────────────────────────────────── */}
      <Section pattern="grid">
        <Reveal>
          <h2 className="heading-silver text-center text-3xl font-bold md:text-[2.75rem]">
            Core Modules
          </h2>
        </Reveal>

        <Reveal>
          <div className="mt-12 border-l border-t border-line-violet">
            {/* Top row: two wide cards */}
            <div className="grid md:grid-cols-2">
              {[first, second].map((m) => (
                <article key={m.name} className="border-b border-r border-line-violet p-8">
                  <ModuleIcon />
                  <h3 className="text-2xl font-bold leading-tight text-violet-bright">{m.name}</h3>
                  <p className="mt-4 text-sm font-semibold leading-relaxed text-fg-soft">
                    {m.body}
                  </p>
                </article>
              ))}
            </div>

            {/* Bottom row: three cards */}
            <div className="grid md:grid-cols-3">
              {rest.map((m, i) => (
                <article key={m.name} className="border-b border-r border-line-violet p-8">
                  <ModuleIcon />
                  <h3
                    className={`text-2xl font-bold leading-tight ${
                      i === 1 ? 'text-white' : 'text-violet-bright'
                    }`}
                  >
                    {m.name}
                  </h3>
                  <p className="mt-4 text-sm font-semibold leading-relaxed text-fg-soft">
                    {m.body}
                  </p>
                </article>
              ))}
            </div>
          </div>
        </Reveal>
      </Section>

      {/* ── Technical highlights ─────────────────────────── */}
      <Section>
        <Reveal>
          <h2 className="heading-silver text-3xl font-bold md:text-[2.75rem]">
            Technical Highlights
          </h2>
        </Reveal>

        <div className="mt-10 grid gap-4 sm:grid-cols-2 lg:grid-cols-4">
          {technicalHighlights.map((h, i) => (
            <Reveal key={h.name} delay={i * 60}>
              <div className="h-full overflow-hidden rounded-[6px] border border-line-violet">
                <div
                  className={`px-4 py-3 ${
                    i === 2 ? 'bg-bg-3 text-fg-silver' : 'bg-violet text-white'
                  }`}
                >
                  <h3 className="text-base font-bold leading-tight">{h.name}</h3>
                </div>
                <p className="px-4 py-5 text-sm leading-relaxed text-fg-soft">{h.body}</p>
              </div>
            </Reveal>
          ))}
        </div>
      </Section>

      {/* ── Comparison ───────────────────────────────────── */}
      <Section pattern="glow">
        <Reveal>
          <h2 className="heading-silver text-3xl font-bold md:text-[2.75rem]">
            Comparison Callout
          </h2>
        </Reveal>

        <Reveal>
          <div className="mt-10 overflow-hidden rounded-[14px] border border-line-violet">
            <table className="w-full text-left">
              <caption className="sr-only">
                Building the decision layer yourself compared with Motus AI Engine.
              </caption>
              <thead>
                <tr className="bg-violet text-white">
                  <th scope="col" className="w-1/3 px-6 py-5" />
                  <th scope="col" className="px-6 py-5 text-xl font-bold">
                    Build it yourself
                  </th>
                  <th scope="col" className="px-6 py-5 text-xl font-bold">
                    Motus AI Engine
                  </th>
                </tr>
              </thead>
              <tbody>
                {comparisonRows.map((row, i) => (
                  <tr key={row} className={i % 2 ? 'bg-bg-2' : 'bg-bg-3/60'}>
                    <th scope="row" className="px-6 py-5 text-sm font-bold text-white">
                      {row}
                    </th>
                    <td className="px-6 py-5 text-sm">
                      <Placeholder>{row} — build it yourself</Placeholder>
                    </td>
                    <td className="px-6 py-5 text-sm">
                      <Placeholder>{row} — Motus AI Engine</Placeholder>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </Reveal>
      </Section>
    </>
  );
}
