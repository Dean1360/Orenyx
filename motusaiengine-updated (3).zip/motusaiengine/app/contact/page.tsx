import { PageHero } from '@/components/page-hero';
import { RequestAccessForm } from '@/components/request-access-form';
import { Reveal } from '@/components/reveal';
import { Section } from '@/components/ui/section';
import { pageMeta } from '@/lib/seo';

export const metadata = pageMeta({
  title: 'Request Access',
  description: 'Request access to Motus AI Engine.',
  path: '/contact',
});

export default function ContactPage() {
  return (
    <>
      <PageHero
        crumb="Contact"
        title="Request Access"
        lead="Tell us what you're routing and we'll get back to you."
      />
      <Section>
        <Reveal>
          <RequestAccessForm />
        </Reveal>
      </Section>
    </>
  );
}
