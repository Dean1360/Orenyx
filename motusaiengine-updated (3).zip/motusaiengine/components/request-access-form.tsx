'use client';

import { useRouter } from 'next/navigation';
import { useState } from 'react';
import { Button } from '@/components/ui/button';

type State = 'idle' | 'sending' | 'error';

const field =
  'mt-2 w-full rounded-[6px] border border-line bg-white px-3.5 py-2.5 text-sm ' +
  'placeholder:text-ink-muted focus:border-violet focus:outline-none';

/**
 * Posts to the internal route handler. If the client chooses an external form
 * service instead, swap the fetch target and delete app/api/request-access.
 */
export function RequestAccessForm() {
  const router = useRouter();
  const [state, setState] = useState<State>('idle');
  const [message, setMessage] = useState('');

  async function handleSubmit() {
    const form = document.getElementById('request-access') as HTMLFormElement | null;
    if (!form) return;
    if (!form.reportValidity()) return;

    setState('sending');
    setMessage('');

    try {
      const data = Object.fromEntries(new FormData(form).entries());
      const res = await fetch('/api/request-access', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(data),
      });

      if (!res.ok) throw new Error(await res.text());
      router.push('/thank-you');
    } catch {
      setState('error');
      setMessage(
        'That request did not go through. Try again, or email support@motuslabs.co directly.',
      );
    }
  }

  return (
    <form id="request-access" className="max-w-[560px]">
      <div className="grid gap-5 sm:grid-cols-2">
        <div>
          <label htmlFor="name" className="font-mono text-eyebrow uppercase text-ink-muted">
            Full name
          </label>
          <input id="name" name="name" required autoComplete="name" className={field} />
        </div>
        <div>
          <label htmlFor="email" className="font-mono text-eyebrow uppercase text-ink-muted">
            Work email
          </label>
          <input
            id="email"
            name="email"
            type="email"
            required
            autoComplete="email"
            className={field}
          />
        </div>
      </div>

      <div className="mt-5">
        <label htmlFor="company" className="font-mono text-eyebrow uppercase text-ink-muted">
          Company
        </label>
        <input id="company" name="company" required autoComplete="organization" className={field} />
      </div>

      <div className="mt-5">
        <label htmlFor="volume" className="font-mono text-eyebrow uppercase text-ink-muted">
          Expected events per month
        </label>
        <select id="volume" name="volume" className={field} defaultValue="">
          <option value="" disabled>
            Select a range
          </option>
          <option>Under 25,000</option>
          <option>25,000 – 250,000</option>
          <option>250,000 – 1 million</option>
          <option>Over 1 million</option>
        </select>
      </div>

      <div className="mt-5">
        <label htmlFor="details" className="font-mono text-eyebrow uppercase text-ink-muted">
          What are you routing?
        </label>
        <textarea id="details" name="details" rows={4} className={field} />
      </div>

      {/* Bot trap. Real people never see it, so anything in it is spam. */}
      <input
        type="text"
        name="company_website"
        tabIndex={-1}
        autoComplete="off"
        aria-hidden="true"
        className="absolute left-[-9999px]"
      />

      <div className="mt-7 flex items-center gap-4">
        <Button type="button" onClick={handleSubmit} disabled={state === 'sending'}>
          {state === 'sending' ? 'Sending' : 'Request access'}
        </Button>
      </div>

      {message ? (
        <p role="alert" className="mt-4 text-sm text-down">
          {message}
        </p>
      ) : null}
    </form>
  );
}
