'use client';

import Link from 'next/link';
import { usePathname } from 'next/navigation';
import { useEffect, useState } from 'react';
import { primaryNav, utilityNav } from '@/content/site';
import { ButtonLink } from '@/components/ui/button';
import { Logo } from '@/components/logo';

export function SiteHeader() {
  const [open, setOpen] = useState(false);
  const pathname = usePathname();

  useEffect(() => setOpen(false), [pathname]);

  useEffect(() => {
    document.body.style.overflow = open ? 'hidden' : '';
    return () => {
      document.body.style.overflow = '';
    };
  }, [open]);

  return (
    <header className="sticky top-0 z-50">
      {/* Utility bar */}
      <div className="bg-lavender">
        <div className="mx-auto flex h-8 w-full max-w-[1180px] items-center justify-end gap-6 px-5 md:px-8">
          {utilityNav.map((item) => (
            <Link
              key={item.href}
              href={item.href}
              className="text-[11px] font-semibold uppercase tracking-wider text-bg hover:text-violet-deep"
            >
              {item.label}
            </Link>
          ))}
        </div>
      </div>

      {/* Main bar */}
      <div className="border-b border-line bg-bg/95 backdrop-blur-md">
        <div className="mx-auto flex h-[70px] w-full max-w-[1180px] items-center justify-between gap-6 px-5 md:px-8">
          <Link href="/" aria-label="Motus AI Engine — home">
            <Logo variant="header" priority />
          </Link>

          <nav aria-label="Primary" className="hidden items-center gap-6 xl:flex">
            {primaryNav.map((item) => {
              const active =
                item.href === '/' ? pathname === '/' : pathname.startsWith(item.href);
              return (
                <Link
                  key={item.href}
                  href={item.href}
                  aria-current={active ? 'page' : undefined}
                  className={`text-sm transition-colors ${
                    active ? 'text-violet-bright' : 'text-fg-soft hover:text-white'
                  }`}
                >
                  {item.label}
                </Link>
              );
            })}
          </nav>

          <ButtonLink href="/contact" className="hidden shrink-0 xl:inline-flex">
            Get Started
          </ButtonLink>

          <button
            type="button"
            onClick={() => setOpen((v) => !v)}
            aria-expanded={open}
            aria-controls="mobile-nav"
            className="grid h-10 w-10 place-items-center rounded-[6px] border border-line text-white xl:hidden"
          >
            <span className="sr-only">{open ? 'Close menu' : 'Open menu'}</span>
            <svg width="18" height="18" viewBox="0 0 18 18" fill="none" aria-hidden="true">
              {open ? (
                <path d="M3 3l12 12M15 3L3 15" stroke="currentColor" strokeWidth="1.6" />
              ) : (
                <path d="M2 5h14M2 9h14M2 13h14" stroke="currentColor" strokeWidth="1.6" />
              )}
            </svg>
          </button>
        </div>
      </div>

      {open ? (
        <div id="mobile-nav" className="border-b border-line bg-bg xl:hidden">
          <nav aria-label="Mobile" className="mx-auto max-w-[1180px] px-5 py-4">
            <ul className="flex flex-col">
              {primaryNav.map((item) => (
                <li key={item.href}>
                  <Link
                    href={item.href}
                    className="block border-b border-line py-3 text-fg-soft hover:text-white"
                  >
                    {item.label}
                  </Link>
                </li>
              ))}
            </ul>
            <ButtonLink href="/contact" className="mt-5 w-full">
              Get Started
            </ButtonLink>
          </nav>
        </div>
      ) : null}
    </header>
  );
}
