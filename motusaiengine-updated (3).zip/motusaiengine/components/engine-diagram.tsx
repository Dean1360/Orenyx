import type { CSSProperties } from 'react';

/**
 * Hero diagram — four Motus products wired into one central engine.
 *
 * Deliberately reduced to the four product feeds. The dense circuit fan looked
 * good in isolation but competed with the headline sitting above it, and cost
 * ~188 simultaneous animations to say what four lines say more clearly.
 *
 * Three motion passes, all on the same four paths:
 *   1. SWEEP — a highlight as long as the wire lights each line from the
 *      product box in to the die, then sweeps off.
 *   2. RIDER — a dot travels the same path on the same clock.
 *   3. PAD PULSE — the four pads where the lines meet the die.
 *
 * Pure SVG + CSS. No canvas, no runtime JavaScript, nothing to tear down on
 * unmount. Product names stay real selectable text. ~13 animations total, so it
 * runs everywhere without a mobile carve-out.
 */

const MOTION = {
  /** Seconds for one sweep pass. */
  dur: 2.6,
  /** Gap between each line firing, seconds. Products arrive in turn. */
  stagger: 0.65,
  /** Seconds for one pad pulse. */
  padDur: 3.4,
} as const;

const W = 1000;
const H = 563;

const CHIP = { x: 420, y: 207, w: 152, h: 152, r: 26 };
const CHIP_CX = CHIP.x + CHIP.w / 2;
const CHIP_CY = CHIP.y + CHIP.h / 2;

const BOX = { w: 222, h: 107, r: 10 };

type Feed = {
  label: [string, string];
  x: number;
  y: number;
  /** Box -> die. Sweeps and riders both run this direction. */
  path: string;
  /** Where the line meets the die. */
  pad: { x: number; y: number };
  /** Approximate path length, for the sweep dash. */
  len: number;
};

const feeds: Feed[] = [
  {
    label: ['Motus Voice', 'Dispatch'],
    x: 61,
    y: 70,
    path: `M183,177 V226 Q183,246 203,246 H${CHIP.x}`,
    pad: { x: CHIP.x, y: 246 },
    len: 300,
  },
  {
    label: ['Social', 'Mention Bot'],
    x: 717,
    y: 70,
    path: `M828,177 V226 Q828,246 808,246 H${CHIP.x + CHIP.w}`,
    pad: { x: CHIP.x + CHIP.w, y: 246 },
    len: 300,
  },
  {
    label: ['Zyntriq', 'Dispatch'],
    x: 61,
    y: 386,
    path: `M183,386 V337 Q183,317 203,317 H${CHIP.x}`,
    pad: { x: CHIP.x, y: 317 },
    len: 300,
  },
  {
    label: ['Motus', 'Payment'],
    x: 717,
    y: 386,
    path: `M828,386 V337 Q828,317 808,317 H${CHIP.x + CHIP.w}`,
    pad: { x: CHIP.x + CHIP.w, y: 317 },
    len: 300,
  },
];

export function EngineDiagram({ className = '' }: { className?: string }) {
  return (
    <svg
      viewBox={`0 0 ${W} ${H}`}
      className={`h-auto w-full ${className}`}
      role="img"
      aria-label="Motus Voice Dispatch, Social Mention Bot, Zyntriq Dispatch and Motus Payment all connected to a central AI engine."
    >
      <defs>
        <linearGradient id="ai-fill" x1="0" y1="0" x2="0" y2="1">
          <stop offset="0%" stopColor="#CFC6FF" />
          <stop offset="100%" stopColor="#6D4FE3" />
        </linearGradient>

        <linearGradient id="die-edge" x1="0" y1="0" x2="1" y2="1">
          <stop offset="0%" stopColor="#A99BFF" />
          <stop offset="100%" stopColor="#5A3FC7" />
        </linearGradient>

        <filter id="bloom" x="-80%" y="-80%" width="260%" height="260%">
          <feGaussianBlur stdDeviation="18" />
        </filter>
      </defs>

      {/* Resting wires */}
      <g fill="none" stroke="#4A3D8F" strokeWidth="2" strokeLinecap="round">
        {feeds.map((f) => (
          <path key={f.path} d={f.path} />
        ))}
      </g>

      {/* Pass 1 — sweep. Dash length equals wire length, so the highlight is
          the whole line rather than a segment travelling along it. */}
      <g fill="none" strokeLinecap="round">
        {feeds.map((f, i) => (
          <path
            key={`sweep-${f.path}`}
            className="trace-sweep"
            d={f.path}
            stroke="#D6D0FF"
            strokeWidth="2.4"
            strokeDasharray={`${f.len} ${f.len}`}
            opacity="0.95"
            style={
              {
                '--len': String(f.len),
                '--dur': `${MOTION.dur}s`,
                '--delay': `${(i * MOTION.stagger).toFixed(2)}s`,
              } as CSSProperties
            }
          />
        ))}
      </g>

      {/* Pass 2 — riders, same path and clock as the sweep. */}
      {feeds.map((f, i) => (
        <circle
          key={`rider-${f.path}`}
          className="feed-dot"
          r="4.5"
          fill="#D6D0FF"
          style={
            {
              offsetPath: `path("${f.path}")`,
              '--dur': `${MOTION.dur}s`,
              '--delay': `${(i * MOTION.stagger).toFixed(2)}s`,
            } as CSSProperties
          }
        />
      ))}

      {/* Pass 3 — pads where each line meets the die. */}
      <g>
        {feeds.map((f, i) => (
          <circle
            key={`pad-${f.path}`}
            className="pad-pulse"
            cx={f.pad.x}
            cy={f.pad.y}
            r="5"
            fill="#8B7CFF"
            opacity="0.9"
            style={
              {
                '--o': '0.9',
                '--pdur': `${MOTION.padDur}s`,
                '--delay': `${(i * MOTION.stagger).toFixed(2)}s`,
              } as CSSProperties
            }
          />
        ))}
      </g>

      {/* Die */}
      <g>
        <rect
          x={CHIP.x}
          y={CHIP.y}
          width={CHIP.w}
          height={CHIP.h}
          rx={CHIP.r}
          fill="#8B7CFF"
          opacity="0.5"
          filter="url(#bloom)"
          className="chip-glow"
        />
        <rect
          x={CHIP.x}
          y={CHIP.y}
          width={CHIP.w}
          height={CHIP.h}
          rx={CHIP.r}
          fill="#131C33"
          stroke="url(#die-edge)"
          strokeWidth="3"
        />
        <text
          x={CHIP_CX}
          y={CHIP_CY + 4}
          textAnchor="middle"
          dominantBaseline="middle"
          fill="url(#ai-fill)"
          fontSize="86"
          fontWeight="800"
          letterSpacing="-2"
        >
          AI
        </text>
      </g>

      {/* Product boxes */}
      {feeds.map((f) => (
        <g key={f.label.join()}>
          <rect
            x={f.x}
            y={f.y}
            width={BOX.w}
            height={BOX.h}
            rx={BOX.r}
            fill="#131C33"
            stroke="#8B7CFF"
            strokeWidth="1.6"
          />
          <text
            x={f.x + BOX.w / 2}
            y={f.y + 42}
            textAnchor="middle"
            fill="#A99BFF"
            fontSize="24"
            fontWeight="600"
          >
            {f.label[0]}
            <tspan x={f.x + BOX.w / 2} dy="30">
              {f.label[1]}
            </tspan>
          </text>
        </g>
      ))}
    </svg>
  );
}
